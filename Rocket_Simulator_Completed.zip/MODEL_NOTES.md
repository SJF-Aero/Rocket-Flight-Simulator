# Engineering model notes

## Sources and configuration

NASA, *Sounding Rockets User Handbook*, NASA/TP-20230006855, Appendix A.5, describes the Terrier MK12–Improved Orion as a two-stage spin-stabilized rocket, approximately **2,850 lb without payload** for the MK12 configuration. The Improved Orion produces approximately **20,000 lbf for its first 6 seconds** and **4,000 lbf to burnout at 24 seconds**. These are rounded descriptions, **not** a digitized motor test curve.

Primary source: https://ntrs.nasa.gov/api/citations/20230006855/downloads/NASA%20TP%2020230006855%202023.05.08.pdf

Older NASA handbooks describe roughly 19,000 lbf for 4 seconds and 3,000 lbf to ~25 seconds. Do not mix editions without noting the configuration and approximation differences.

The first-stage ~257.5 kN thrust figure and ~578 kg propellant / ~322 kg unpropelled figures are **secondary-source, configuration-unverified estimates** discussed during independent review. They are not certified NASA MK12 flight data. In particular, **257.5 kN is treated as an illustrative constant near-peak thrust, not a verified average or measured curve**. The modeled ~4.4 s burn is likewise provisional. These values should be replaced when a trustworthy motor-specific record becomes available.

## Model input table

| Input | Value | Provenance |
|---|---:|---|
| MK12 booster diameter | 0.4572 m | NASA 18 in |
| Orion diameter | 0.3556 m | NASA 14 in |
| Vehicle reference, no payload | 2850 lb | NASA approximate |
| Payload | 300 lb | User-selected scenario within NASA payload range |
| Orion boost / sustain | 20,000 / 4,000 lbf | NASA approximate |
| Orion duration | 24 s | NASA approximate |
| Terrier stage propellant | 578 kg | Unverified secondary estimate |
| Terrier stage dry | 322 kg | Unverified secondary estimate; may omit hardware |
| Terrier thrust | 257.5 kN near-constant | Illustrative, not a measured history |
| Terrier burn | 4.4 s | Provisional |
| Orion propellant | 378.769 kg | Inferred from impulse at assumed Isp 230 s |
| Orion stage dry | 150 kg | Assumption |
| Cd(M) | See Flight.py | Assumption |
| Stage ignition delay | 0 s | Simplifying assumption |

The model's vehicle component mass is ~1428.77 kg excluding payload, about **136.03 kg heavier** than the NASA approximate 1292.74 kg reference. This mismatch is deliberately retained rather than absorbed into a fake dry-mass residual. A true mass reconciliation would need a consistent motor/stage/hardware inventory.

## Governing physics

The vertical equation of motion is `dv/dt = (thrust + drag) / mass - g(h)`, with drag `-0.5*rho*v*abs(v)*Cd*A`. Dynamic pressure is `0.5*rho*v**2`. Gravity changes with altitude. Pressure and density follow a layered lower-atmosphere model and interpolated upper-atmosphere table. Burn propellant use is proportional to integrated thrust-curve impulse; stages separate at burnout without a delay. The final coast is integrated until upward velocity reaches zero.

For a constant-thrust drag-free burn near ground level, the reference equation is `v = (F/mdot)*ln(m0/mf) - g*t`. A drag-free constant-g coast gives additional altitude `v0**2/(2*g)`. These serve as physics checks, not flight validation.

Nozzle equations assume choked flow, ideal isentropic expansion, and `F = mdot*Ve + (Pe-Pa)*Ae`. The sweep from expansion ratio 2 to 30 does not model flow separation and is therefore optimistic when highly overexpanded. The optimum for attached ideal flow is close to `Pe = Pa`.

## Verification and uncertainty

- 13 automated tests include analytic rocket-equation comparison, impulse integration, atmosphere checks, mass accounting, no-liftoff behavior, timestep refinement, nozzle Mach-area inversion, and nozzle expansion checks.
- Outputs are reproducible for the installed Python and NumPy/Matplotlib versions; see logs.
- The current illustrative scenario is not independently validated against a matched NASA launch configuration. An apogee numerically near or far from NASA handbook plots cannot establish model accuracy without matching launch angle, aerodynamic model, vehicle mass, payload and motor histories.
- No engineering flight-safety, structural-load, nozzle fabrication, or mission-design qualification is claimed.

## Next physical validation step

Obtain configuration-matched MK12 and Improved Orion thrust-time and propellant/loaded/dry mass data from primary motor records, establish what the 2,850 lb vehicle mass includes, and use a documented Cd curve and launch geometry. Then repeat convergence, uncertainty, and NASA comparison studies. This is a data gap, not a reason to silently tune parameters to match an apogee chart.
