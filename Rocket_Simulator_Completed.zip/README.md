# Multistage Rocket Flight Simulator

A Python 1-D vertical two-stage rocket flight simulator and a separate ideal nozzle performance study. The project uses simple functions, a time-step integration loop, and Matplotlib plots.

## Run

Install Python 3.10+ and then:

```
python -m pip install -r requirements.txt
python Flight.py
python Nozzle.py
python -m unittest -v Test_Flight
```

`Flight.py` opens one window with eight graphs, including two zoomed powered-flight views. `Nozzle.py` opens one window with seven graphs. Both scripts print numerical results. Use a normal desktop Python/Matplotlib backend for pop-up windows.

## Results and interpretation

The **current illustrative scenario** gives an apogee of about **258 km**. This is **not** a validated prediction for a NASA Terrier Mk12–Improved Orion. Its Terrier thrust approximation uses a constant near-peak thrust, which is not a measured thrust history. The approximate 2,850 lb published NASA vehicle mass is **not forced** onto the independent assumed component masses; the resulting difference is reported openly. See `MODEL_NOTES.md`.

The **original 127 km baseline** is preserved in `baseline/Flight_original_baseline.py` for comparison; it uses the older unverified first-stage inputs and a mass-balance plug. Do not use that baseline as evidence of validation.

## Model boundaries

- One-dimensional vertical flight, variable gravity, US Standard Atmosphere-based model, Mach-dependent assumed Cd.
- Two thrust-curve stages with instantaneous separation and ignition. No pitch, wind, staging delay, powered-flight base-drag correction, or attitude dynamics.
- Thrust curves are assumed independent of ambient pressure. Propellant consumption is distributed in proportion to impulse for the thrust-curve case.
- Nozzle model assumes ideal, isentropic, attached flow. It is a **separate analysis**, not the source of the flight thrust curves. No separation, viscous, or divergence losses are modeled.
- Current NASA handbook is a reference for approximate vehicle configuration and Orion boost/sustain levels, not proof that the illustrative inputs match a flown vehicle.

## Files

- `Flight.py`: simulation and flight graphs
- `Nozzle.py`: nozzle calculations and seven-graph dashboard
- `Test_Flight.py`: numerical, physical, and edge-case tests
- `MODEL_NOTES.md`: data provenance, equations, assumptions, remaining validation gaps
- `flight_output.txt`, `nozzle_output.txt`, `test_results.txt`: reproducible run logs
- `baseline/Flight_original_baseline.py`: prior model retained for traceability

## What is verified

The code runs, the tests pass, mass is conserved in the modeled burns, and timestep refinement is stable for the supplied inputs. **Physical flight-performance validation is not claimed.** The remaining gap is obtaining exact, configuration-matched motor mass and thrust histories and aerodynamic data.
